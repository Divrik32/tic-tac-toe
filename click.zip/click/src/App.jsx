import './App.css'
import BoxButtons from './components/BoxButtons'
import BoxButtons1 from './components/BoxButtons1'
import BoxButtons2 from './components/BoxButtons2'
import Click from './components/Click'

function App() {

  return (
<>
<BoxButtons2/>
</>
  )
}

export default App
