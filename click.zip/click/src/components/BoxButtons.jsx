import React, { useState } from "react";

const BoxButtons = () => {
  // State for the game board
  let [finalArray, setFinalArray] = useState(Array(9).fill(null));
  
  // State for tracking whose turn it is
  const [xTurn, setXTurn] = useState(true);
  
  // State to display the winner
  const [winner, setWinner] = useState(null);

  // Winning conditions
  const winningPatterns = [
    [0, 1, 2], // Row 1
    [3, 4, 5], // Row 2
    [6, 7, 8], // Row 3
    [0, 3, 6], // Column 1
    [1, 4, 7], // Column 2
    [2, 5, 8], // Column 3
    [0, 4, 8], // Diagonal 1
    [2, 4, 6], // Diagonal 2
  ];

  // Handle the button click
  const handleClick = (index) => {
    // If the cell is already filled, do nothing
    if (finalArray[index] !== null || winner) {
      return;
    }

    // Create a copy of the current game board
    let updatedBoard = [...finalArray];
    // Set the current player's symbol (X or O)
    updatedBoard[index] = xTurn ? "X" : "O";
    setFinalArray(updatedBoard);

    // Check if there's a winner
    for (let i = 0; i < winningPatterns.length; i++) {
      const [a, b, c] = winningPatterns[i];
      if (updatedBoard[a] && updatedBoard[a] === updatedBoard[b] && updatedBoard[a] === updatedBoard[c]) {
        setWinner(updatedBoard[a]);
        return;
      }
    }

    // Toggle the turn
    setXTurn(!xTurn);
  };

  // Render each cell in the table
  const handleBox = (index) => {
    return (
      <button
        onClick={() => handleClick(index)}
        style={{ color: "white", background: "red", width: "50px", height: "50px" }}
      >
        {finalArray[index]}
      </button>
    );
  };

  return (
    <div>
      <table>
        <thead>
          <tr>
            <td>{handleBox(0)}</td>
            <td>{handleBox(1)}</td>
            <td>{handleBox(2)}</td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{handleBox(3)}</td>
            <td>{handleBox(4)}</td>
            <td>{handleBox(5)}</td>
          </tr>
          <tr>
            <td>{handleBox(6)}</td>
            <td>{handleBox(7)}</td>
            <td>{handleBox(8)}</td>
          </tr>
        </tbody>
      </table>
      <br /><br />
      <h1>{winner ? `Winner is ${winner}` : `It's ${xTurn ? 'X' : 'O'}'s turn`}</h1>
    </div>
  );
};

export default BoxButtons;
