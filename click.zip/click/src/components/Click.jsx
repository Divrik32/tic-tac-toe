import React, { useState } from 'react'

const Click = () => {
    const [click1,setClick1]=useState('R')
    const [click2,setClick2]=useState('K')
    const [click3,setClick3]=useState('L')
    const [click4,setClick4]=useState('S')

    const [bColor1,setBColor1]=useState('red')
    const [bColor2,setBColor2]=useState('green')
    const [bColor3,setBColor3]=useState('yellow')
    const [bColor4,setBColor4]=useState('blue')

    const handleClick1 =()=>{
        if(click1==="R" && bColor1==='red'){
          setClick1('K')
          setBColor1('green')
        }else if(click1==="K" && bColor1==='green'){
          setClick1('L')  
          setBColor1('yellow')
        }else if(click1==="L" && bColor1==='yellow'){
            setClick1('S')  
            setBColor1('blue')
          }
        else{
            setClick1('R')
            setBColor1('red')
        }
    }
    const handleClick2 =()=>{
        if(click2==="R" && bColor2==='red'){
          setClick2('K')
          setBColor2('green')
        }else if(click2==="K" && bColor2==='green'){
          setClick2('L')  
          setBColor2('yellow')
        }else if(click2==="L" && bColor2==='yellow'){
            setClick2('S')  
            setBColor2('blue')
          }
        else{
            setClick2('R')
            setBColor2('red')
        }
    }
    const handleClick3 =()=>{
        if(click3==="R" && bColor3==='red'){
          setClick3('K')
          setBColor3('green')
        }else if(click3==="K" && bColor3==='green'){
          setClick3('L')  
          setBColor3('yellow')
        }else if(click3==="L" && bColor3==='yellow'){
            setClick3('S')  
            setBColor3('blue')
          }
        else{
            setClick3('R')
            setBColor3('red')
        }
    }
    const handleClick4 =()=>{
        if(click4==="R" && bColor4==='red'){
          setClick4('K')
          setBColor4('green')
        }else if(click4==="K" && bColor4==='green'){
          setClick4('L')  
          setBColor4('yellow')
        }else if(click4==="L" && bColor4==='yellow'){
            setClick4('S')  
            setBColor4('blue')
          }
        else{
            setClick4('R')
            setBColor4('red')
        }
    }
    const buttonRefresh=()=>{
        setClick1('R')
        setClick2('K')
        setClick3('L')
        setClick4('S')
        setBColor1('red')
        setBColor2('green')
        setBColor3('yellow')
        setBColor4('blue')

    }
  return (
    <div>
        <button style={{background:bColor1,color:'white',margin:'2px'}} onClick={()=>handleClick1()}>{click1}</button>
        <button style={{background:bColor2,color:'white',margin:'2px'}} onClick={()=>handleClick2()}>{click2}</button><br />
        <button style={{background:bColor3,color:'white',margin:'2px'}} onClick={()=>handleClick3()}>{click3}</button>
        <button style={{background:bColor4,color:'white',margin:'2px'}} onClick={()=>handleClick4()}>{click4}</button>
           <br /><br />
           <button onClick={()=>buttonRefresh()}>Refresh</button>
    </div>
  )
}

export default Click