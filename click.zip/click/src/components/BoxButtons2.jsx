import React, { useState } from "react";

const BoxButtons2 = () => {
  let [finalArray, setFinalArray] = useState(Array(9).fill(null));
  const [xturn, setXturn] = useState(true);
  const [winner, setWinner] = useState(null);

  const winningPatterns = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  const handleClick = (index) => {
    if (finalArray[index] !== null || winner) {
      return;
    }
    const updatedBoard = [...finalArray];
    updatedBoard[index] = xturn ? "X" : "O";
    setFinalArray(updatedBoard);
    for (let i = 0; i < winningPatterns.length; i++) {
      const [a, b, c] = winningPatterns[i];
      if (
        updatedBoard[a] &&
        updatedBoard[a] == updatedBoard[b] &&
        updatedBoard[a] == updatedBoard[c]
      ) {
        setWinner(updatedBoard[a]);
        return;
      }
    }
    setXturn(!xturn);
  };
  const handleBox = (index) => {
    return (
      <button
        style={{
          color: "white",
          background: "red",
          width: "50px",
          height: "50px",
        }}
        onClick={() => handleClick(index)}
      >
        {finalArray[index]}
      </button>
    );
  };
  return (
    <div>
      <table>
        <thead>
          <tr>
            <td>{handleBox(0)}</td>
            <td>{handleBox(1)}</td>
            <td>{handleBox(2)}</td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{handleBox(3)}</td>
            <td>{handleBox(4)}</td>
            <td>{handleBox(5)}</td>
          </tr>
          <tr>
            <td>{handleBox(6)}</td>
            <td>{handleBox(7)}</td>
            <td>{handleBox(8)}</td>
          </tr>
        </tbody>
      </table>
      <br />
      <br />
      <h1>
        {winner ? `winner is ${winner}` : `It's ${xturn ? "X" : "O"} turn`}
      </h1>
    </div>
  );
};

export default BoxButtons2;
